// script.js

document.getElementById('createFileBtn').addEventListener('click', function() {
    const fileName = document.getElementById('fileName').value;
    const fileSize = document.getElementById('fileSize').value;
    const allocationMethod = document.getElementById('allocationMethod').value;

    if (!fileName) {
        alert('Please enter a file name.');
        return;
    }

    const logMessage = `File created: ${fileName}, Size: ${fileSize}, Allocation Method: ${allocationMethod}`;
    addToLog(logMessage);
    updateMetrics();
});

document.getElementById('deleteFileBtn').addEventListener('click', function() {
    const fileName = document.getElementById('fileName').value;

    if (!fileName) {
        alert('Please enter a file name to delete.');
        return;
    }

    const logMessage = `File deleted: ${fileName}`;
    addToLog(logMessage);
    updateMetrics();
});

document.getElementById('allocateBlocksBtn').addEventListener('click', function() {
    const logMessage = 'Blocks allocated!';
    addToLog(logMessage);
    updateMetrics();
});

function updateMetrics() {
    // Simulate updating metrics
    const fragmentationValue = Math.floor(Math.random() * 100) + '%';
    const performanceValue = Math.floor(Math.random() * 200) + 'ms';

    document.getElementById('fragmentation').innerText = 'Fragmentation: ' + fragmentationValue;
    document.getElementById('performance').innerText = 'Performance: ' + performanceValue;
}

function addToLog(message) {
    const logDiv = document.getElementById('log');
    const logEntry = document.createElement('div');
    logEntry.innerText = message;
    logDiv.appendChild(logEntry);
}

